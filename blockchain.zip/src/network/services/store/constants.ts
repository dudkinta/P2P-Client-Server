export const PROTOCOL_VERSION = "1.0.0";
export const PROTOCOL_NAME = "store";
export const PROTOCOL_PREFIX = "chain";
export const TIMEOUT = 10000;
export const MAX_INBOUND_STREAMS = 64;
export const MAX_OUTBOUND_STREAMS = 64;
