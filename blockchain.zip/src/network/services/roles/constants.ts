export const PROTOCOL_VERSION = "1.0.0";
export const PROTOCOL_NAME = "roles";
export const PROTOCOL_PREFIX = "chain";
export const TIMEOUT = 10000;
export const MAX_INBOUND_STREAMS = 20;
export const MAX_OUTBOUND_STREAMS = 20;
