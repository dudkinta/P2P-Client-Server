export enum LogLevel {
  Critical = "CRITICAL",
  Error = "ERROR",
  Warning = "WARNING",
  Info = "INFO",
  Debug = "DEBUG",
  Trace = "TRACE",
}
