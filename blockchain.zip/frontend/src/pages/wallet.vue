<template>
  <div class="wallet"></div>
</template>
